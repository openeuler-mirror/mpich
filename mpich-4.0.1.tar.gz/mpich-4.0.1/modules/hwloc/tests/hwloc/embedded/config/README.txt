This file exists solely so that the config/ directory exists in git checkouts.
