/*
 * Copyright (C) by Argonne National Laboratory
 *     See COPYRIGHT in top-level directory
 */

#ifndef YAKSURI_ZE_POST_H_INCLUDED
#define YAKSURI_ZE_POST_H_INCLUDED

int yaksuri_ze_init_hook(yaksur_gpudriver_hooks_s ** hooks);

#endif /* YAKSURI_ZE_H_INCLUDED */
